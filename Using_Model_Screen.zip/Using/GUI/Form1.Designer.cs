﻿namespace GUI
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            ListViewGroup listViewGroup1 = new ListViewGroup("ListViewGroup", HorizontalAlignment.Left);
            groupBox1 = new GroupBox();
            groupBox2 = new GroupBox();
            cmbLoaibinhluan = new ComboBox();
            lvAnalyze = new ListView();
            columnHeader2 = new ColumnHeader();
            columnHeader3 = new ColumnHeader();
            rbtnTieucuc = new RadioButton();
            rbtnTichCuc = new RadioButton();
            cboModel = new ComboBox();
            groupBox3 = new GroupBox();
            PicNenMua = new PictureBox();
            PicBinhThuong = new PictureBox();
            PicKhongNenMua = new PictureBox();
            btnStartAnalyze = new Button();
            label13 = new Label();
            btnLoadModel = new Button();
            btnUploadProduct = new Button();
            label2 = new Label();
            label17 = new Label();
            label18 = new Label();
            panel2 = new Panel();
            comboBox1 = new ComboBox();
            label1 = new Label();
            lvComments = new ListView();
            columnHeader1 = new ColumnHeader();
            groupBox1.SuspendLayout();
            groupBox2.SuspendLayout();
            groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)PicNenMua).BeginInit();
            ((System.ComponentModel.ISupportInitialize)PicBinhThuong).BeginInit();
            ((System.ComponentModel.ISupportInitialize)PicKhongNenMua).BeginInit();
            panel2.SuspendLayout();
            SuspendLayout();
            // 
            // groupBox1
            // 
            groupBox1.BackColor = SystemColors.GradientInactiveCaption;
            groupBox1.Controls.Add(groupBox2);
            groupBox1.Controls.Add(cboModel);
            groupBox1.Controls.Add(groupBox3);
            groupBox1.Controls.Add(btnStartAnalyze);
            groupBox1.Controls.Add(label13);
            groupBox1.Controls.Add(btnLoadModel);
            groupBox1.Font = new Font("Segoe UI Black", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            groupBox1.Location = new Point(69, 382);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(1324, 530);
            groupBox1.TabIndex = 14;
            groupBox1.TabStop = false;
            groupBox1.Text = "Analyze with Traned Model";
            // 
            // groupBox2
            // 
            groupBox2.BackColor = SystemColors.Info;
            groupBox2.Controls.Add(cmbLoaibinhluan);
            groupBox2.Controls.Add(lvAnalyze);
            groupBox2.Controls.Add(rbtnTieucuc);
            groupBox2.Controls.Add(rbtnTichCuc);
            groupBox2.Location = new Point(6, 106);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(796, 424);
            groupBox2.TabIndex = 37;
            groupBox2.TabStop = false;
            groupBox2.Text = "Danh sách comments";
            // 
            // cmbLoaibinhluan
            // 
            cmbLoaibinhluan.FormattingEnabled = true;
            cmbLoaibinhluan.Items.AddRange(new object[] { "Bình luận về sản phẩm", "Bình luận về dịch vụ" });
            cmbLoaibinhluan.Location = new Point(41, 39);
            cmbLoaibinhluan.Name = "cmbLoaibinhluan";
            cmbLoaibinhluan.Size = new Size(329, 40);
            cmbLoaibinhluan.TabIndex = 40;
            cmbLoaibinhluan.Text = "Chọn loại bình luận";
            cmbLoaibinhluan.SelectedIndexChanged += comboBox1_SelectedIndexChanged;
            // 
            // lvAnalyze
            // 
            lvAnalyze.Columns.AddRange(new ColumnHeader[] { columnHeader2, columnHeader3 });
            lvAnalyze.FullRowSelect = true;
            lvAnalyze.GridLines = true;
            lvAnalyze.Location = new Point(41, 100);
            lvAnalyze.Name = "lvAnalyze";
            lvAnalyze.Size = new Size(745, 318);
            lvAnalyze.TabIndex = 2;
            lvAnalyze.UseCompatibleStateImageBehavior = false;
            lvAnalyze.View = View.Details;
            lvAnalyze.SelectedIndexChanged += lvAnalyze_SelectedIndexChanged;
            // 
            // columnHeader2
            // 
            columnHeader2.Text = "Comments";
            columnHeader2.Width = 600;
            // 
            // columnHeader3
            // 
            columnHeader3.Text = "Sentiment";
            columnHeader3.Width = 200;
            // 
            // rbtnTieucuc
            // 
            rbtnTieucuc.AutoSize = true;
            rbtnTieucuc.Location = new Point(603, 41);
            rbtnTieucuc.Name = "rbtnTieucuc";
            rbtnTieucuc.Size = new Size(143, 36);
            rbtnTieucuc.TabIndex = 1;
            rbtnTieucuc.TabStop = true;
            rbtnTieucuc.Text = "Tiêu cực";
            rbtnTieucuc.UseVisualStyleBackColor = true;
            rbtnTieucuc.CheckedChanged += rbtnTieucuc_CheckedChanged;
            // 
            // rbtnTichCuc
            // 
            rbtnTichCuc.AutoSize = true;
            rbtnTichCuc.Location = new Point(417, 39);
            rbtnTichCuc.Name = "rbtnTichCuc";
            rbtnTichCuc.Size = new Size(142, 36);
            rbtnTichCuc.TabIndex = 0;
            rbtnTichCuc.TabStop = true;
            rbtnTichCuc.Text = "Tích cực";
            rbtnTichCuc.UseVisualStyleBackColor = true;
            rbtnTichCuc.CheckedChanged += rbtnTichCuc_CheckedChanged;
            // 
            // cboModel
            // 
            cboModel.FormattingEnabled = true;
            cboModel.Location = new Point(184, 52);
            cboModel.Name = "cboModel";
            cboModel.Size = new Size(545, 40);
            cboModel.TabIndex = 39;
            cboModel.Text = "chọn tên model name";
            cboModel.SelectedIndexChanged += cboModel_SelectedIndexChanged;
            // 
            // groupBox3
            // 
            groupBox3.Controls.Add(PicNenMua);
            groupBox3.Controls.Add(PicBinhThuong);
            groupBox3.Controls.Add(PicKhongNenMua);
            groupBox3.Font = new Font("Rockwell", 9F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            groupBox3.ForeColor = SystemColors.HotTrack;
            groupBox3.Location = new Point(810, 115);
            groupBox3.Name = "groupBox3";
            groupBox3.Size = new Size(514, 382);
            groupBox3.TabIndex = 36;
            groupBox3.TabStop = false;
            groupBox3.Text = "Có nên mua sản phầm này không nhỉ?";
            groupBox3.Enter += groupBox3_Enter;
            // 
            // PicNenMua
            // 
            PicNenMua.Image = (Image)resources.GetObject("PicNenMua.Image");
            PicNenMua.Location = new Point(0, 38);
            PicNenMua.Name = "PicNenMua";
            PicNenMua.Size = new Size(473, 318);
            PicNenMua.SizeMode = PictureBoxSizeMode.StretchImage;
            PicNenMua.TabIndex = 3;
            PicNenMua.TabStop = false;
            PicNenMua.Visible = false;
            PicNenMua.Click += PicNenMua_Click;
            // 
            // PicBinhThuong
            // 
            PicBinhThuong.Image = (Image)resources.GetObject("PicBinhThuong.Image");
            PicBinhThuong.Location = new Point(6, 38);
            PicBinhThuong.Name = "PicBinhThuong";
            PicBinhThuong.Size = new Size(467, 318);
            PicBinhThuong.SizeMode = PictureBoxSizeMode.StretchImage;
            PicBinhThuong.TabIndex = 2;
            PicBinhThuong.TabStop = false;
            PicBinhThuong.Visible = false;
            PicBinhThuong.Click += PicBinhThuong_Click;
            // 
            // PicKhongNenMua
            // 
            PicKhongNenMua.Image = (Image)resources.GetObject("PicKhongNenMua.Image");
            PicKhongNenMua.Location = new Point(-2, 38);
            PicKhongNenMua.Name = "PicKhongNenMua";
            PicKhongNenMua.Size = new Size(467, 318);
            PicKhongNenMua.SizeMode = PictureBoxSizeMode.StretchImage;
            PicKhongNenMua.TabIndex = 1;
            PicKhongNenMua.TabStop = false;
            PicKhongNenMua.Visible = false;
            PicKhongNenMua.Click += PicKhongNenMua_Click;
            // 
            // btnStartAnalyze
            // 
            btnStartAnalyze.Location = new Point(958, 47);
            btnStartAnalyze.Name = "btnStartAnalyze";
            btnStartAnalyze.Size = new Size(317, 54);
            btnStartAnalyze.TabIndex = 34;
            btnStartAnalyze.Text = "Start Analyze Product";
            btnStartAnalyze.UseVisualStyleBackColor = true;
            btnStartAnalyze.Click += button1_Click;
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Font = new Font("Segoe UI", 10.125F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label13.Location = new Point(6, 51);
            label13.Name = "label13";
            label13.Size = new Size(172, 37);
            label13.TabIndex = 33;
            label13.Text = "Model Name";
            // 
            // btnLoadModel
            // 
            btnLoadModel.Location = new Point(757, 47);
            btnLoadModel.Name = "btnLoadModel";
            btnLoadModel.Size = new Size(195, 53);
            btnLoadModel.TabIndex = 31;
            btnLoadModel.Text = "Load Model";
            btnLoadModel.UseVisualStyleBackColor = true;
            btnLoadModel.Click += btnLoadModel_Click;
            // 
            // btnUploadProduct
            // 
            btnUploadProduct.Location = new Point(1037, 7);
            btnUploadProduct.Name = "btnUploadProduct";
            btnUploadProduct.Size = new Size(207, 56);
            btnUploadProduct.TabIndex = 0;
            btnUploadProduct.Text = "Upload";
            btnUploadProduct.UseVisualStyleBackColor = true;
            btnUploadProduct.Click += btnUploadProduct_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 10.125F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label2.Location = new Point(46, 101);
            label2.Name = "label2";
            label2.Size = new Size(0, 37);
            label2.TabIndex = 23;
            // 
            // label17
            // 
            label17.AutoSize = true;
            label17.Font = new Font("Segoe UI", 10.125F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label17.Location = new Point(56, 15);
            label17.Name = "label17";
            label17.Size = new Size(115, 37);
            label17.TabIndex = 21;
            label17.Text = "Product:";
            label17.Click += label17_Click;
            // 
            // label18
            // 
            label18.AutoSize = true;
            label18.Font = new Font("Segoe UI", 10.125F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label18.Location = new Point(77, 103);
            label18.Name = "label18";
            label18.Size = new Size(0, 37);
            label18.TabIndex = 22;
            // 
            // panel2
            // 
            panel2.BackColor = SystemColors.ActiveCaption;
            panel2.BorderStyle = BorderStyle.FixedSingle;
            panel2.Controls.Add(comboBox1);
            panel2.Controls.Add(btnUploadProduct);
            panel2.Controls.Add(label2);
            panel2.Controls.Add(label17);
            panel2.Controls.Add(label18);
            panel2.Location = new Point(69, 83);
            panel2.Name = "panel2";
            panel2.Size = new Size(1324, 78);
            panel2.TabIndex = 12;
            // 
            // comboBox1
            // 
            comboBox1.FormattingEnabled = true;
            comboBox1.Items.AddRange(new object[] { "sách đắc nhân tâm", "vợt cầu lông k520pro", "giày yonex z63" });
            comboBox1.Location = new Point(183, 16);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new Size(825, 40);
            comboBox1.TabIndex = 16;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Britannic Bold", 19.875F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label1.ForeColor = SystemColors.Highlight;
            label1.Location = new Point(69, 9);
            label1.Name = "label1";
            label1.Size = new Size(346, 58);
            label1.TabIndex = 11;
            label1.Text = "USING MODEL";
            label1.Click += label1_Click;
            // 
            // lvComments
            // 
            lvComments.Columns.AddRange(new ColumnHeader[] { columnHeader1 });
            lvComments.FullRowSelect = true;
            lvComments.GridLines = true;
            listViewGroup1.Header = "ListViewGroup";
            listViewGroup1.Name = "column";
            lvComments.Groups.AddRange(new ListViewGroup[] { listViewGroup1 });
            lvComments.Location = new Point(69, 167);
            lvComments.Name = "lvComments";
            lvComments.Size = new Size(1324, 209);
            lvComments.TabIndex = 15;
            lvComments.Tag = "gg";
            lvComments.UseCompatibleStateImageBehavior = false;
            lvComments.View = View.Details;
            lvComments.SelectedIndexChanged += lvComments_SelectedIndexChanged;
            // 
            // columnHeader1
            // 
            columnHeader1.Text = "Comments về sản phẩm";
            columnHeader1.Width = 500;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(13F, 32F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1408, 962);
            Controls.Add(lvComments);
            Controls.Add(groupBox1);
            Controls.Add(panel2);
            Controls.Add(label1);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load_1;
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            groupBox3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)PicNenMua).EndInit();
            ((System.ComponentModel.ISupportInitialize)PicBinhThuong).EndInit();
            ((System.ComponentModel.ISupportInitialize)PicKhongNenMua).EndInit();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private GroupBox groupBox1;
        private GroupBox groupBox3;
        private Button btnStartAnalyze;
        private Label label13;
        private TextBox textBox13;
        private Button btnLoadModel;
        private Button btnUploadProduct;
        private Label label2;
        private Label label17;
        private Label label18;
        private Panel panel2;
        private Label label1;
        private ListView lvComments;
        private ColumnHeader columnHeader1;
        private ComboBox cboModel;
        private GroupBox groupBox2;
        private RadioButton rbtnTieucuc;
        private RadioButton rbtnTichCuc;
        private ListView lvAnalyze;
        private ColumnHeader columnHeader2;
        private ColumnHeader columnHeader3;
        private PictureBox PicBinhThuong;
        private PictureBox PicKhongNenMua;
        private PictureBox PicNenMua;
        private ComboBox cmbLoaibinhluan;
        private ComboBox comboBox1;
    }
}
