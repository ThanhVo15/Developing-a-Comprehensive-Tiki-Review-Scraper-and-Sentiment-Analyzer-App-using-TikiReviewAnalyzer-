﻿using DTO;
using DAL;
using BLL;
using System;
using System.ComponentModel;
using System.IO;
using System.Linq;
using Microsoft.ML;
using Microsoft.ML.Data;
using static Microsoft.ML.DataOperationsCatalog;
using System.Net.Http.Headers;
using Newtonsoft.Json.Linq;


namespace GUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }


        private MLContext mlContext = new MLContext(42);
        private ITransformer model;
        string folder = @"E:\Models";
        //string folder = "Models";

        private void btnUploadProduct_Click(object sender, EventArgs e)
        {
            CommentsBLL cmtbll = new CommentsBLL();
            List<Comments> dscmt = cmtbll.LaytoanboCmt();
            lvComments.Items.Clear();
            foreach (Comments cmt in dscmt)
            {
                ListViewItem lvi = new ListViewItem(cmt.column1);
                lvComments.Items.Add(lvi);

            }
        }

        private void lvComments_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btnLoadModel_Click(object sender, EventArgs e)
        {
            // Kiểm tra xem người dùng đã chọn model trong ComboBox chưa
            if (cboModel.SelectedIndex == -1)
            {
                MessageBox.Show("Vui lòng chọn một model.");
                return;
            }

            // Lấy tên model từ ComboBox
            string selectedModel = cboModel.SelectedItem.ToString();

            // Hiển thị thông báo xác nhận model đã sẵn sàng để sử dụng
            MessageBox.Show("Model '" + selectedModel + "' đã được chọn và sẵn sàng để phân tích.");
        }





        private void cboModel_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
        private void LoadModelIntoCombo()
        {
            cboModel.Items.Clear();
            string[] modelFiles = Directory.GetFiles(folder, "*.zip"); // Nếu bạn lưu mô hình dưới dạng zip hoặc một định dạng khác
            foreach (var file in modelFiles)
            {
                FileInfo fi = new FileInfo(file);
                cboModel.Items.Add(fi.Name);
            }
        }



        private void Form1_Load_1(object sender, EventArgs e)
        {
            LoadModelIntoCombo();
        }

        private async void button1_Click(object sender, EventArgs e)
        {
            if (cboModel.SelectedIndex == -1)
            {
                MessageBox.Show("Vui lòng chọn một model.");
                return;
            }

            if (lvComments.Items.Count == 0)
            {
                MessageBox.Show("Không có comment nào để phân tích.");
                return;
            }

            // Xóa nội dung cũ trong lvAnalyze
            lvAnalyze.Items.Clear();

            // Load mô hình đã huấn luyện
            string modelPath = @"E:\Models\SentimentModel1.zip"; // Đường dẫn đến tệp mô hình
            MLContext mlContext = new MLContext();
            ITransformer loadedModel = mlContext.Model.Load(modelPath, out var modelInputSchema);
            var predictionEngine = mlContext.Model.CreatePredictionEngine<CommentData, SentimentPrediction>(loadedModel);

            // Biến đếm số lượng bình luận tích cực, tiêu cực và trung lập
            int positiveCount = 0;
            int negativeCount = 0;
            int neutralCount = 0;

            foreach (ListViewItem item in lvComments.Items)
            {
                string comment = item.Text;

                // Phân tích cảm xúc của bình luận bằng mô hình đã huấn luyện
                var input = new CommentData { Comment = comment };
                var prediction = predictionEngine.Predict(input);

                // Thêm kết quả vào lvAnalyze
                ListViewItem resultItem = new ListViewItem(comment); // Thêm comment gốc
                resultItem.SubItems.Add(prediction.Sentiment); // Thêm kết quả phân tích cảm xúc
                lvAnalyze.Items.Add(resultItem);

                // Đếm số bình luận tích cực, tiêu cực và trung lập
                if (prediction.Sentiment == "Tích cực")
                {
                    positiveCount++;
                }
                else if (prediction.Sentiment == "Tiêu cực")
                {
                    negativeCount++;
                }
                else
                {
                    neutralCount++;
                }
            }

            // Tính tỷ lệ tích cực và tiêu cực
            double totalComments = lvComments.Items.Count;
            double positivePercentage = (positiveCount / totalComments) * 100;
            double negativePercentage = (negativeCount / totalComments) * 100;

            // Thay đổi trạng thái hiển thị các PictureBox dựa trên tỷ lệ tích cực và tiêu cực
            if (positivePercentage > 60)
            {
                PicNenMua.Visible = true;
                PicBinhThuong.Visible = false;
                PicKhongNenMua.Visible = false;
            }
            else if (positivePercentage >= 50 && positivePercentage <= 60)
            {
                PicNenMua.Visible = false;
                PicBinhThuong.Visible = true;
                PicKhongNenMua.Visible = false;
            }
            else
            {
                PicNenMua.Visible = false;
                PicBinhThuong.Visible = false;
                PicKhongNenMua.Visible = true;
            }

            MessageBox.Show("Phân tích hoàn tất.");
        }


        private string AnalyzeSentiment(string comment, List<string> positiveWords, List<string> negativeWords)
        {
           
            string lowerCaseComment = comment.ToLower();

           
            bool isPositive = positiveWords.Any(word => lowerCaseComment.Contains(word));
           
            bool isNegative = negativeWords.Any(word => lowerCaseComment.Contains(word));

          
            if (isPositive && !isNegative)
            {
                return "Tích cực";
            }
            else if (isNegative && !isPositive)
            {
                return "Tiêu cực";
            }
            else if (isPositive && isNegative)
            {
                return "Hỗn hợp";
            }
            else
            {
                return "Không xác định";
            }
        }





        private void lvAnalyze_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void PicBinhThuong_Click(object sender, EventArgs e)
        {

        }

        private void PicKhongNenMua_Click(object sender, EventArgs e)
        {

        }

        private void PicNenMua_Click(object sender, EventArgs e)
        {

        }

        private void label17_Click(object sender, EventArgs e)
        {

        }

        private void rbtnTichCuc_CheckedChanged(object sender, EventArgs e)
        {
            if (rbtnTichCuc.Checked)
            {
                FilterComments("Tích cực");
            }
        }

        private void rbtnTieucuc_CheckedChanged(object sender, EventArgs e)
        {
            if (rbtnTieucuc.Checked)
            {
                FilterComments("Tiêu cực");
            }
        }

        //private async Task<string> AnalyzeSentimentWithModel(string comment, ITransformer model)
        //{
        //    var predictionEngine = mlContext.Model.CreatePredictionEngine<CommentData, SentimentPrediction>(model);

        //    // Dự đoán cảm xúc của bình luận
        //    var prediction = predictionEngine.Predict(new CommentData { Text = comment });

        //    return prediction.Prediction; // Trả về kết quả (Tích cực, Tiêu cực)
        //}

       

       

        public class CommentData
        {
            [LoadColumn(0)]
            public string Comment { get; set; }
        }

        public class SentimentPrediction : CommentData
        {
            [ColumnName("PredictedLabel")]
            public string Sentiment { get; set; }
        }

        private void FilterComments(string sentiment)
        {
            // Xóa tất cả các mục hiện tại trong ListView
            lvAnalyze.Items.Clear();

            // Danh sách từ khóa tích cực và tiêu cực
            List<string> positiveWords = new List<string> { "tốt", "hay", "đẹp", "được", "ok", "hài lòng", "sướng", "thích" };
            List<string> negativeWords = new List<string> { "không", "dở", "tệ", "thối", "chán", "xấu", "sai", "tồi", "phí" };

            foreach (ListViewItem item in lvComments.Items)
            {
                string comment = item.Text;

                // Phân tích cảm xúc của bình luận
                string analysisResult = AnalyzeSentiment(comment, positiveWords, negativeWords);

                // Chỉ thêm bình luận nếu nó khớp với loại cảm xúc được chọn
                if (analysisResult == sentiment || sentiment == "Tất cả")
                {
                    ListViewItem resultItem = new ListViewItem(comment); // Thêm comment gốc
                    resultItem.SubItems.Add(analysisResult); // Thêm kết quả phân tích cảm xúc
                    lvAnalyze.Items.Add(resultItem);
                }
            }
        }

        private void groupBox3_Enter(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}