﻿using Microsoft.ML.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DTO
{
    class CommentData
    {
        public string Text { get; set; }
    }
    public class CommentPrediction
    {
        [ColumnName("output")] // Tên cột đầu ra của mô hình ONNX
        public float[] PredictedLabel { get; set; }
    }
}