﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DTO;
using System.Data;
using System.Data.SqlClient;


namespace DAL
{
    public class Comments_Access:DatabaseAccess
    {
       public List<Comments>LaytoanboCmt()
        {
            List<Comments> dsCommnets = new List<Comments>();
            OpenConnection();
            SqlCommand command = new SqlCommand();
            command.CommandType = CommandType.Text;
            command.CommandText = "Select * from Comments";
            command.Connection = conn;

            SqlDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                string column1 = reader.GetString(0);

                Comments cmt = new Comments();
                cmt.column1 = column1;
                dsCommnets.Add(cmt);
            }    
            reader.Close();
            return dsCommnets;
        }

    }
}
