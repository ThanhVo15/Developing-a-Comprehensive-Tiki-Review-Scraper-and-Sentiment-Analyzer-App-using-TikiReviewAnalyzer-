﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace DAL
{
    public class DatabaseAccess
    {
       
        // Chuỗi kết nối không cần mật khẩu (sử dụng Windows Authentication)
        string strConn= "Server=DESKTOP-76OC15R;Database=ThanhLuan;Trusted_Connection=True;";
        public SqlConnection conn = null;
        public void OpenConnection()
        {
            if(conn == null) 
                conn = new SqlConnection(strConn);
            if(conn.State == System.Data.ConnectionState.Closed)
                conn.Open();
        }
        public void CloseConnection()
        {
            if (conn != null && conn.State == System.Data.ConnectionState.Open)
                conn.Close();
             
        }
        
    }
}
